# LICENSE #

*All of the files in this folder are licensed under a [Creative Commons Attribution-ShareAlike 3.0 Unported License](http://creativecommons.org/licenses/by-sa/3.0/) and the [Open Source Hardware (OSHW) Definition 1.0](http://freedomdefined.org/OSHW).*

[![alt][2]][1] [![alt][4]][3]

[1]: http://creativecommons.org/licenses/by-sa/3.0/
[2]: http://i.creativecommons.org/l/by-sa/3.0/88x31.png (Creative Commons Attribution-ShareAlike 3.0 Unported License.)

[3]: http://freedomdefined.org/OSHW
[4]: http://ultimachine.com/sites/default/files/images/OpenHardwareLogo.thumbnail.png



----------

# Disclaimer #

THE CONTENT OF THIS FOLDER IS PROVIDED "AS IS" AND "WITH ALL FAULTS". ACRONET&reg; DISCLAIMS ALL OTHER WARRANTIES, EXPRESS OR IMPLIED, REGARDING PRODUCTS, INCLUDING BUT NOT LIMITED TO, ANY IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.